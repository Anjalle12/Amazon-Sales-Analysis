USE amazon_sales; 
USE amazon_sales_data;  
ALTER TABLE amazon_sales_data ADD COLUMN converted_time TIME; 
UPDATE amazon_sales_data
SET time = TIME_FORMAT(STR_TO_DATE(time, '%h:%i:%s %p'), '%H:%i:%s');
SELECT time FROM amazon_sales_data
WHERE STR_TO_DATE(time, '%h:%i %p') IS NULL; 
UPDATE amazon_sales_data
SET time = '00:00:00'
WHERE STR_TO_DATE(time, '%h:%i %p') IS NULL; 
UPDATE amazon_sales_data
SET time = TIME_FORMAT(STR_TO_DATE(time, '%h:%i %p'), '%H:%i:%s');
SELECT * FROM amazon_sales_data LIMIT 10; 
ALTER TABLE amazon_sales_data ADD COLUMN timeofday VARCHAR(20);
ALTER TABLE amazon_sales_data ADD COLUMN dayname VARCHAR(20);
ALTER TABLE amazon_sales_data ADD COLUMN monthname VARCHAR(20); 
DESCRIBE amazon_sales_data; 
UPDATE amazon_sales_data
SET timeofday = CASE 
    WHEN HOUR(time) BETWEEN 6 AND 12 THEN 'Morning'
    WHEN HOUR(time) BETWEEN 12 AND 18 THEN 'Afternoon'
    WHEN HOUR(time) BETWEEN 18 AND 24 THEN 'Evening'
    ELSE 'Night'
END;
UPDATE amazon_sales_data
SET dayname = DAYNAME(date); 
SELECT date FROM amazon_sales_data LIMIT 10; 
UPDATE amazon_sales_data
SET date = STR_TO_DATE(date, '%d-%m-%Y'); 
SELECT date FROM amazon_sales_data LIMIT 10; 
UPDATE amazon_sales_data
SET monthname = MONTHNAME(date); 

-- product analysis questions 
-- 1.Count of distinct product lines in the dataset 
SELECT COUNT(DISTINCT `Product line`) AS distinct_product_lines FROM amazon_sales_data;  
 -- 2. Product line with the highest sales
SELECT `Product line` AS Product_line_alias, SUM(total) AS total_sales
FROM amazon_sales_data
GROUP BY Product_line_alias
ORDER BY total_sales DESC
LIMIT 1; 
-- 3. Which product line generated the highest revenue:
SELECT `Product line`, SUM(total) AS total_revenue
FROM amazon_sales_data
GROUP BY `Product line`
ORDER BY total_revenue DESC
LIMIT 1; 
-- 4. Product Line with the Highest Sales in Terms of Quantity
SELECT `Product line`, SUM(quantity) AS total_quantity
FROM amazon_sales_data
GROUP BY `Product line`
ORDER BY total_quantity DESC
LIMIT 1;
-- 5.product Line Incurred the Highest Value Added Tax (VAT)
SELECT `Product line`, SUM(`tax 5%`) AS total_tax
FROM amazon_sales_data
GROUP BY `Product line`
ORDER BY total_tax DESC
LIMIT 1;

-- 6. Which product line is most frequently associated with each gender
SELECT `Product line`, gender, COUNT(*) AS frequency
FROM amazon_sales_data
GROUP BY `Product line`, gender
ORDER BY frequency DESC; 

-- 7.For Each Product Line, Add a Column Indicating "Good" if Its Sales Are Above Average, Otherwise "Bad"
SELECT `Product line`, 
       SUM(total) AS total_sales,
       CASE 
           WHEN SUM(total) > (SELECT AVG(total) FROM amazon_sales_data) THEN 'Good'
           ELSE 'Bad'
       END AS sales_status
FROM amazon_sales_data
GROUP BY `Product line`;

-- 8. Product Line Has the Highest Gross Income 
SELECT `Product line`, SUM(`gross income`) AS total_gross_income
FROM amazon_sales_data
GROUP BY `Product line`
ORDER BY total_gross_income DESC
LIMIT 1;

-- 9. SALES ANALYSIS Queries 
-- Count of distinct cities in the dataset
SELECT COUNT(DISTINCT city) AS distinct_cities FROM amazon_sales_data; 
-- 10.For each branch, what is the corresponding city
SELECT branch, city
FROM amazon_sales_data
GROUP BY branch, city;

-- 11. Revenue generated each month 
SELECT monthname, SUM(total) AS monthly_revenue
FROM amazon_sales_data 
GROUP BY monthname
ORDER BY FIELD(monthname, 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');


-- 12. Month when cost of goods sold (COGS) peaked
SELECT monthname, SUM(cogs) AS total_cogs
FROM amazon_sales_data
GROUP BY monthname
ORDER BY total_cogs DESC
LIMIT 1; 
 
-- 13. City with the highest revenue
SELECT city, SUM(total) AS total_revenue
FROM amazon_sales_data
GROUP BY city
ORDER BY total_revenue DESC
LIMIT 1;
 
 -- 14. Branch that exceeded the average number of products sold
SELECT branch, SUM(quantity) AS total_products_sold
FROM amazon_sales_data
GROUP BY branch
HAVING total_products_sold > (SELECT AVG(quantity) FROM amazon_sales_data);

-- 15. Count sales occurrences for each time of day on every weekday
SELECT dayname, timeofday, COUNT(*) AS sales_count
FROM amazon_sales_data
GROUP BY dayname, timeofday
ORDER BY dayname, timeofday; 

-- 16. Time of day with the highest customer ratings for each branch
SELECT branch, timeofday, AVG(rating) AS avg_rating
FROM amazon_sales_data
GROUP BY branch, timeofday
ORDER BY branch, avg_rating DESC;

-- 17. Day of the week with the highest average ratings for each branch
SELECT branch, dayname, AVG(rating) AS avg_rating
FROM amazon_sales_data
GROUP BY branch, dayname
ORDER BY branch, avg_rating DESC; 

 -- 18. Payment method that occurs most frequently
SELECT payment, COUNT(*) AS frequency
FROM amazon_sales_data
GROUP BY payment
ORDER BY frequency DESC
LIMIT 1; 

-- CUSTOMER ANALYSIS QUERIES 
--  19.Count of distinct customer types in the dataset
SELECT COUNT(DISTINCT `Customer type`) AS distinct_customer_types
FROM amazon_sales_data;

-- 20. Customer type occurring most frequently:
SELECT `Customer type`, COUNT(*) AS frequency
FROM amazon_sales_data
GROUP BY `Customer type`
ORDER BY frequency DESC
LIMIT 1; 

-- 21. Identify the customer type contributing the highest revenue.
SELECT `Customer type`, SUM(total) AS total_revenue
FROM amazon_sales_data
GROUP BY `Customer type`
ORDER BY total_revenue DESC
LIMIT 1; 

-- 22. Identify the Customer Type with the Highest VAT Payments
SELECT `Customer type`, SUM(`Tax 5%`) AS total_vat
FROM amazon_sales_data
GROUP BY `Customer type`
ORDER BY total_vat DESC
LIMIT 1;

-- 23. Identify the customer type with the highest purchase frequency.
SELECT `Customer type`, COUNT(*) AS purchase_frequency
FROM amazon_sales_data
GROUP BY `Customer type`
ORDER BY purchase_frequency DESC
LIMIT 1;

 -- 25.  Determine the predominant gender among customers.
SELECT gender, COUNT(*) AS gender_count
FROM amazon_sales_data
GROUP BY gender
ORDER BY gender_count DESC
LIMIT 1;

-- 26. Examine the distribution of genders within each customer type.
SELECT `Customer type`, gender, COUNT(*) AS gender_count
FROM amazon_sales_data
GROUP BY `Customer type`, gender
ORDER BY `Customer type`, gender_count DESC; 

-- 27. Identify the customer type contributing the highest ratings.
SELECT `Customer type`, AVG(rating) AS avg_rating
FROM amazon_sales_data
GROUP BY `Customer type` 
ORDER BY avg_rating DESC
LIMIT 1;

-- 28. Count the number of occurrences of each customer type.
SELECT `Customer type`, COUNT(*) AS customer_type_count
FROM amazon_sales_data
GROUP BY `Customer type`; 






